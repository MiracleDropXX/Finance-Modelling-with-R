# -*- coding: utf-8 -*-
"""
Created on Mon Oct 15 11:46:21 2018

@author: Tybalt4175
"""

from pylab import plot, show
import matplotlib.pyplot as plt

from scipy import linspace, mean, exp, randn, log
from scipy.optimize import fminbound
from lininterp import LinInterp

N = 10
theta = 0.5
alpha = 0.28
beta = 0.9

def U(c): return 1-exp(-theta*c)
def f(k): return k**alpha


gridmin, gridmax, gridsize = 0.1, 10, 150
grid = linspace(gridmin, gridmax**1e-1, gridsize)**10

def maximum(h, a, b):
    return float(h(fminbound(lambda x: - h(x), a, b)))

def bellman(w):
    values = []
    for k in grid:
        h = lambda k1: U(f(k)-k1) + beta*w(k1)
        values.append(maximum(h, 0, f(k)))
    return LinInterp(grid, values)
    


K_space = linspace(0, 10, 1000)
# First five iterates 
V_0 = U
V_1 = bellman(V_0)
V_2 = bellman(V_1)
V_3 = bellman(V_2)
V_4 = bellman(V_3)
V_5 = bellman(V_4)

V = U
for n in range(10):
    V = bellman(V)    

V_10 = V


V = U

for n in range(100):
    V = bellman(V)    
    plt.plot(K_space, [V(k) for k in K_space], color="red", linewidth=1, linestyle="-")

V_100 = V

# Graphical output:   
plt.plot(K_space, [V_0(k) for k in K_space], color="black", linewidth=1, linestyle="-", label=r'$V_0$')
plt.plot(K_space, [V_1(k) for k in K_space], color="blue", linewidth=1, linestyle="-", label=r'$V_1$')
plt.plot(K_space, [V_2(k) for k in K_space], color="green", linewidth=1, linestyle="-", label=r'$V_2$')
plt.plot(K_space, [V_3(k) for k in K_space], color="purple", linewidth=1, linestyle="-", label=r'$V_3$')
plt.plot(K_space, [V_4(k) for k in K_space], color="brown", linewidth=1, linestyle="-", label=r'$V_4$')
plt.plot(K_space, [V_5(k) for k in K_space], color="yellow", linewidth=1, linestyle="-", label=r'$V_5$')
plt.plot(K_space, [V_10(k) for k in K_space], color="red", linewidth=1, linestyle="-", label=r'$V_{10}$')
plt.plot(K_space, [V_100(k) for k in K_space], color="black", linewidth=1, linestyle="-", label=r'$V_{100}$')

plt.legend(loc='lower right')
plt.xlabel("$k$", horizontalalignment='right', x = 1.0) 
plt.ylabel("$V_n(k)$", horizontalalignment='right', y = 1.0) 
plt.savefig('Value_function_iteration_2_100.eps', format='eps', dpi=1000)

