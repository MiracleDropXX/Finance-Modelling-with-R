# Open in e.g., https://gke.mybinder.org/v2/gh/ipython/ipython-in-depth/master?filepath=binder/Index.ipynb 
# Author: 	Andre Meyer-Wehmann
# Date: 	04.07.2019 Ffm 
# Institution: 	Goethe University
# Course: 	Credit Risk 
# Semester: 	Summer 2019

import numpy as np
import matplotlib.pyplot as plt
from ipywidgets import interact, interactive, fixed, interact_manual
import ipywidgets as widgets

def portfolio_loss(loss=10,plot_on=1,ABS_equity=5, ABS_mezz = 20, ABS_sen=75, CDO_equity=5, CDO_mezz = 20, CDO_sen=75):
    ABS_equity_rem =  np.maximum(ABS_equity-loss,0)
    ABS_equity_loss = np.minimum(loss,ABS_equity)
    ABS_equity_perc = ABS_equity_loss/ABS_equity*100
    loss_rem_1 = np.maximum(loss - ABS_equity,0)
    ABS_mezz_loss = np.minimum(loss_rem_1,ABS_mezz)
    ABS_mezz_rem = np.maximum(ABS_mezz-loss_rem_1,0)  
    ABS_mezz_perc = ABS_mezz_loss/ABS_mezz*100
    loss_rem_2 = np.maximum(loss_rem_1 - ABS_mezz,0)
    ABS_sen_rem = np.maximum(ABS_sen-loss_rem_2,0)  
    ABS_sen_loss = np.minimum(loss_rem_2,ABS_sen)
    ABS_sen_perc = ABS_sen_loss/ABS_sen*100
    CDO_equity_rem = np.maximum(CDO_equity-loss_rem_1,0)
    CDO_equity_loss = np.minimum(loss_rem_1,CDO_equity)
    CDO_equity_perc = CDO_equity_loss/CDO_equity*100
    loss_rem_3 = np.maximum(ABS_mezz_perc - CDO_equity,0)
    CDO_mezz_loss = np.minimum(loss_rem_3,CDO_mezz)
    CDO_mezz_rem = np.maximum(CDO_mezz-loss_rem_3,0)  
    CDO_mezz_perc = CDO_mezz_loss/CDO_mezz*100
    loss_rem_4 = np.maximum(loss_rem_3 - CDO_mezz,0)
    CDO_sen_loss = np.minimum(loss_rem_4,CDO_sen)
    CDO_sen_rem = np.maximum(CDO_sen-loss_rem_4,0)  
    CDO_sen_perc = CDO_sen_loss/CDO_sen*100
    
    if plot_on==1:
        plt.figure(figsize=(40,20))    
        plt.subplot(2, 1, 1)
        remainder = (ABS_equity_rem, ABS_mezz_rem, ABS_sen_rem, CDO_equity_rem, CDO_mezz_rem,CDO_sen_rem)
        losses = (ABS_equity_loss, ABS_mezz_loss, ABS_sen_loss, CDO_equity_loss,CDO_mezz_loss, CDO_sen_loss)
        ind = np.arange(6)    
        width = 0.4       

        p1= plt.bar(ind, remainder, width)
        p2= plt.bar(ind, losses, width,  bottom=remainder)

        plt.ylabel('Value',fontsize =25, weight='heavy')
        plt.title('Remainder and losses by tranche',fontsize =25, weight='heavy')
        plt.xticks(ind, ('ABS_Equity', 'ABS_Mezz', 'ABS_Senior', 'CDO_Equity', 'CDO_Mezz', 'CDO_Senior'),fontsize =25, weight='heavy')
        for index,data in enumerate(np.round(losses,2)):
            plt.text(x=index - 0.1 , y =90, s='Loss: ' f"{data}" , fontdict=dict(fontsize=20),weight='heavy')
        for index,data in enumerate(np.round(remainder,2)):
            plt.text(x=index - 0.1 , y =80, s='Rem: ' f"{data}" , fontdict=dict(fontsize=20),weight='heavy')

        plt.yticks(np.arange(0, 110, 10))
        plt.legend((p1[0], p2[0]), ('Remainder', 'Loss'),prop={'size': 25})

        plt.subplot(2, 1, 2)
        percent = (ABS_equity_perc, ABS_mezz_perc, ABS_sen_perc, CDO_equity_perc,CDO_mezz_perc, CDO_sen_perc)
        p3= plt.bar(ind, percent, width)
        plt.ylabel('Percentage Loss',fontsize =25, weight='heavy')
        plt.title('Percentage Loss by tranche',fontsize =25, weight='heavy')
        plt.xticks(ind, ('ABS_Equity', 'ABS_Mezz', 'ABS_Senior', 'CDO_Equity', 'CDO_Mezz', 'CDO_Senior'), fontsize =25, weight='heavy')
        plt.yticks(np.arange(0, 110, 10))
        for index,data in enumerate(np.round(percent,2)):
            plt.text(x=index - 0.1 , y =data + 1, s=f"{data}" , fontdict=dict(fontsize=25),weight='heavy')
        plt.show()
    
    return  ABS_equity_rem, ABS_equity_loss, ABS_equity_perc, \
        ABS_mezz_loss, ABS_mezz_rem, ABS_mezz_perc, \
        ABS_sen_rem, ABS_sen_loss, ABS_sen_perc, \
        CDO_equity_rem, CDO_equity_loss, CDO_equity_perc, \
        CDO_mezz_rem, CDO_mezz_loss, CDO_mezz_perc, \
        CDO_sen_rem, CDO_sen_loss, CDO_sen_perc, \
        loss_rem_1,loss_rem_2, loss_rem_3, loss_rem_4        

interactive_plot = interactive(portfolio_loss,{'manual': True}, loss=(0, 100,1),plot_on=fixed(1),ABS_equity=fixed(5), ABS_mezz = fixed(20), ABS_sen=fixed(75), CDO_equity=fixed(5), CDO_mezz = fixed(20), CDO_sen=fixed(75))
output = interactive_plot.children[-1]
interactive_plot