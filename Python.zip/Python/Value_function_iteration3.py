# -*- coding: utf-8 -*-
"""
Created on Mon Oct 15 11:46:21 2018

@author: Tybalt4175
"""

from pylab import plot, show
import matplotlib.pyplot as plt
from scipy import linspace, mean, exp, randn, log
from scipy.optimize import fminbound
from lininterp import LinInterp

N = 100
theta = 0.5
alpha = 0.28
beta = 0.9

def U(c): return 1-exp(-theta*c)
def f(k, xi): return xi*(k**alpha)

W = exp(randn(1000))

gridmin, gridmax, gridsize = 0.5, 10, 150
grid = linspace(gridmin, gridmax**1e-1, gridsize)**10

def maximum(h, a, b):
    return float(h(fminbound(lambda x: - h(x), a, b)))

def bellman(w):
    values = []
    for y in grid:
        h = lambda k: U(y-k) + beta*mean(w(f(k,W)))
        values.append(maximum(h, 0, y))
    return LinInterp(grid, values)


#Copied:
Y_space = linspace(0.1, 10, 1000)
# First five iterates 
V_0 = U
V_1 = bellman(V_0)
V_2 = bellman(V_1)
V_3 = bellman(V_2)
V_4 = bellman(V_3)
V_5 = bellman(V_4)

# First 10 iterates:    
V = U
for n in range(10):
    V = bellman(V)

V_10 = V

# First 100 iterates
V = U
for n in range(100):
    V = bellman(V)    
    plt.plot(Y_space, [V(y) for y in Y_space], color="red", linewidth=1, linestyle="-")

V_100 = V

# Graphical output:   
plt.plot(Y_space, [V_0(y) for y in Y_space], color="black", linewidth=1, linestyle="-", label=r'$V_0$')
plt.plot(Y_space, [V_1(y) for y in Y_space], color="blue", linewidth=1, linestyle="-", label=r'$V_1$')
plt.plot(Y_space, [V_2(y) for y in Y_space], color="green", linewidth=1, linestyle="-", label=r'$V_2$')
plt.plot(Y_space, [V_3(y) for y in Y_space], color="purple", linewidth=1, linestyle="-", label=r'$V_3$')
plt.plot(Y_space, [V_4(y) for y in Y_space], color="brown", linewidth=1, linestyle="-", label=r'$V_4$')
plt.plot(Y_space, [V_5(y) for y in Y_space], color="yellow", linewidth=1, linestyle="-", label=r'$V_5$')
plt.plot(Y_space, [V_10(y) for y in Y_space], color="red", linewidth=1, linestyle="-", label=r'$V_{10}$')
plt.plot(Y_space, [V_100(y) for y in Y_space], color="black", linewidth=1, linestyle="-", label=r'$V_{100}$')
plt.legend(loc='lower right')
plt.legend(loc='lower right')
plt.xlabel("$y$", horizontalalignment='right', x = 1.0) 
plt.ylabel("$V_n(y)$", horizontalalignment='right', y = 1.0) 
plt.savefig('Value_function_iteration3_100.eps', format='eps', dpi=1000)
   
    
