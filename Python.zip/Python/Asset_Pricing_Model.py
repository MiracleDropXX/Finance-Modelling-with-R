# -*- coding: utf-8 -*-
"""
Created on Sat Jun  9 09:54:06 2018

@author: Tybalt4175
"""

from genfinitemc import sample, MC
from numpy import *
from numpy import ones, identity, transpose
from numpy.linalg import solve
from scipy.optimize import *
from pylab import plot, show
import matplotlib.pyplot as plt



# Economic parameters
beta = 0.9
sigma = 0.5
# Number of states
N = 3
# State space ('bad', 'ok', 'good')
S = (0,1,2)
# Initial distribution of states
pi_0 = (0, 1, 0)      
# Transition matrix 
Pi=((0.4, 0.6, 0.0),
    (0.2, 0.6, 0.2),
    (0.0, 0.6, 0.4))
# Initialize object of class Markov chain required by class 'genfinitemc'
h = MC(p=Pi, X = sample(pi_0))
# Dividends in each state:
D = (0.0, 0.1, 0.15)
# Non-capital incomes in each state:
W = (0.6, 0.7, 0.8)

# Initial distribution of states
pi_0 = (0, 1, 0)


h = MC(p=Pi, X = sample(pi_0))

# Function to compute invariant distribution
def inv_distr(Pi_matrix):
    n = len(Pi[1])
    I = identity(n)
    Q,b = ones((n,n)), ones((n,1))
    A = transpose(I - Pi_matrix + Q) 
    pi_inv = solve(A,b)
    return pi_inv 

# Function which computes the expected value of discrete random variable X with distribution pi:
def E(X, pi):
    E_value= 0
    for i in range(len(pi)):
        E_value += X[i]*pi[i]
    return E_value
    
# Euler equation defining equilibriumm asset prices:       
def Euler(P):
    F = empty((3))
    V = [beta*(W[s] + D[s])**(-sigma)*(P[s] + D[s]) for s in S]
    F = [(W[s] + D[s])**(-sigma)*P[s] - E(V,Pi[s]) for s in S]
    return F

# Function which determines P to solve Euler equations using P_guess as an initial guess
def fixed_point_P(P_guess):
    P = fsolve(Euler, P_guess)
    return P 

# Compute invariant distribution 
pi_star = inv_distr(Pi)
# Computing equilibrium asset pricing function P* (the list (.1,.2,.31) is an initial guess for P_star)
P_star = fixed_point_P((.1,.2,.31))

# Computing equilibrium bond return function R* (Z_star is just an auxilliary term)
Z_star = [beta*(W[s] + D[s])**(-sigma) for s in S]
R_star = [((W[s] + D[s])**(-sigma))/E(Z_star, Pi[s])  for s in S]

# Check if equilibrium prices satisfy equilibrium conditions in all states: All of the following checks must be (close to) zero:  
V_star = [beta*(W[s] + D[s])**(-sigma)*(P_star[s] + D[s]) for s in S]
Check_0 = (W[0] + D[0])**(-sigma)*P_star[0] - E(V_star, Pi[0])
Check_1 = (W[1] + D[1])**(-sigma)*P_star[1] - E(V_star, Pi[1])
Check_2 = (W[2] + D[2])**(-sigma)*P_star[2] - E(V_star, Pi[2])
Check_3 = (W[0] + D[0])**(-sigma)- (E(Z_star, Pi[0]))*R_star[0]
Check_4 = (W[1] + D[1])**(-sigma) - (E(Z_star, Pi[1]))*R_star[1]
Check_5 = (W[2] + D[2])**(-sigma) - (E(Z_star, Pi[2]))*R_star[2]


# Compute time series' of the equilibrium variables 
# Length of iteration
T = 500
# Draws a sample of the state process. (Note you need the class 'genfinitemc' to be in the working directory)
S_series = h.sample_path(T+1)
#Arrays to store time series of variables: 
p_series = []
R_series = []
d_series = []
w_series = []
# Initial conditions: 
p_old = 1
R_stock = 1
p = 1
# Iteration function: 
for t in range(T+1):
    # Store asset price from previous period:     
    p_old = p
    # State s_t:
    s = S_series[t]
    # Dividend d_t:
    d = D[s]
    d_series.append(d)
    # Non-capital income w_t: 
    w = W[s]
    w_series.append(w)
    # Asset price p_t:
    p = P_star[s]
    p_series.append(p)
    # Bond return R_{t+1}:
    R = R_star[s]
    R_series.append(R)
    # Stock return R_t^{stock}:  
    R_stock = (p + d)/p_old
    


print("The end!")