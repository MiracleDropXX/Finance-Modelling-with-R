# -*- coding: utf-8 -*-
"""
Created on Sat Jun  9 09:54:06 2018

@author: Tybalt4175
"""

from random import uniform

def sample(pi):
    # pi is a finite distribution, sample returns a realization drawn from it
    a = 0.0
    U = uniform(0,1)
    for i in range(len(pi)):
        if a < U < a + pi[i]:
            return i
        a = a +pi[i]


class MC:
    def __init__(self, p=None, X=None):
        self.p, self.X = p,X
    
#    def update_distribution(spi):
 #       n = len(pi)
        #print("Have a nice day")
        
    def update(self):
        self.X = sample(self.p[self.X])

    def sample_path(self, n):
        path = []
        for i in range(n):
            path.append(self.X)
            self.update()
        return path    
# number of states
