# -*- coding: utf-8 -*-
"""
Created on Mon Oct 15 11:46:21 2018

@author: Tybalt4175
"""

from pylab import plot, show
import matplotlib.pyplot as plt

# Length of iteration:
T = 50
# Parameter:
A = 3.7
# Initial values:
X_0 = (1/10, 1/2, 8/10)
# Fixed point:
x_bar = (A-1)/A
# Array to store values in:
x_sequence = []

# Define time-one map 
def phi(x):
    phi_value = A*x*(1-x)
    return phi_value

# Iterate map for T periods for the different initial values in X_0
for x in X_0:
    for t in range(T+1):
        x_sequence.append(x)
        x = phi(x)
        
# Graphical output:   
plt.plot(x_sequence[0:T], 'bo', label="$x_0 = 0.1$")
plt.plot(x_sequence[T+1:2*T + 1], 'ro', label="$x_0 = 0.5$")
plt.plot(x_sequence[2*T + 2: 3*T + 2], 'go', label="$x_0 = 0.8$")
x_bar_line = [x_bar]*T
plt.plot(x_bar_line[0:T], color="black", linewidth=1, linestyle="--", label=r'$\bar{x}$')
plt.xlabel("$t$", horizontalalignment='right', x = 1.0) 
plt.ylabel("$x_t$", horizontalalignment='right', y = 1.0) 
#plt.yticks('$x_t$', rotation='horizontal')
plt.ylim(0,1)
plt.legend(loc='lower right')
#plt.savefig('Logistic5.eps', format='eps', dpi=1000)
plt.show()

